package com.example.cleantouch.data.model

import com.google.firebase.firestore.DocumentId

data class User(
    val uid: String = "",
    val fullName: String = "",
    val email: String = "",
    val phone: String = ""
)

data class Service(
    @DocumentId val id: String = "",
    val name: String = "",
    val description: String = "",
    val price: Double = 0.0,
    val imageUrl: String = "",
    val durationMinutes: Int = 0
)

data class Booking(
    @DocumentId val id: String = "",
    val userId: String = "",
    val serviceId: String = "",
    val serviceName: String = "",
    val serviceImageUrl: String = "",
    val bookingDate: Long = 0L,
    val location: String = "",
    val notes: String = "",
    val status: String = "Upcoming" // Upcoming, Completed, Cancelled
)