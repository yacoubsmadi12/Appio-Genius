package com.example.cleantouch.data.repository

import com.example.cleantouch.common.Result
import com.example.cleantouch.data.model.Service
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.tasks.await
import javax.inject.Inject

interface ServiceRepository {
    suspend fun getServices(): Result<List<Service>>
    suspend fun getServiceById(serviceId: String): Result<Service?>
}

class ServiceRepositoryImpl @Inject constructor(
    private val firestore: FirebaseFirestore
) : ServiceRepository {

    init {
        // Add dummy data if collection is empty
        addDummyServicesIfNeeded()
    }

    override suspend fun getServices(): Result<List<Service>> {
        return try {
            val snapshot = firestore.collection("services").get().await()
            val services = snapshot.toObjects(Service::class.java)
            Result.Success(services)
        } catch (e: Exception) {
            Result.Error(e)
        }
    }

    override suspend fun getServiceById(serviceId: String): Result<Service?> {
        return try {
            val document = firestore.collection("services").document(serviceId).get().await()
            val service = document.toObject(Service::class.java)
            Result.Success(service)
        } catch (e: Exception) {
            Result.Error(e)
        }
    }

    private fun addDummyServicesIfNeeded() {
        val servicesCollection = firestore.collection("services")
        servicesCollection.limit(1).get().addOnSuccessListener { snapshot ->
            if (snapshot.isEmpty) {
                val dummyServices = listOf(
                    Service(name = "Carpet Cleaning", description = "Deep clean for all types of carpets.", price = 99.99, imageUrl = "https://picsum.photos/seed/carpet/400/300", durationMinutes = 120),
                    Service(name = "Car Wash", description = "Exterior and interior car wash.", price = 45.50, imageUrl = "https://picsum.photos/seed/carwash/400/300", durationMinutes = 60),
                    Service(name = "Garden Care", description = "Lawn mowing and garden maintenance.", price = 75.00, imageUrl = "https://picsum.photos/seed/garden/400/300", durationMinutes = 90),
                    Service(name = "Kitchen Cleaning", description = "Complete kitchen deep clean.", price = 120.00, imageUrl = "https://picsum.photos/seed/kitchen/400/300", durationMinutes = 180),
                    Service(name = "Window Cleaning", description = "Streak-free cleaning for all windows.", price = 80.0, imageUrl = "https://picsum.photos/seed/window/400/300", durationMinutes = 90),
                    Service(name = "Office Cleaning", description = "Daily or weekly office cleaning services.", price = 200.0, imageUrl = "https://picsum.photos/seed/office/400/300", durationMinutes = 240)
                )
                dummyServices.forEach { service ->
                    servicesCollection.add(service)
                }
            }
        }
    }
}