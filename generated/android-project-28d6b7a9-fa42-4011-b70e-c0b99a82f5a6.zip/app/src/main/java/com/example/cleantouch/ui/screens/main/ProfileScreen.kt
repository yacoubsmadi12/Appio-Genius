package com.example.cleantouch.ui.screens.main

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavController
import com.example.cleantouch.common.Result
import com.example.cleantouch.ui.navigation.Screen
import com.example.cleantouch.ui.viewmodel.ProfileViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProfileScreen(
    navController: NavController,
    viewModel: ProfileViewModel = hiltViewModel()
) {
    val userProfileState by viewModel.userProfile.collectAsStateWithLifecycle()
    val updateState by viewModel.updateState.collectAsStateWithLifecycle()
    val snackbarHostState = remember { SnackbarHostState() }

    var fullName by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }

    LaunchedEffect(userProfileState) {
        if (userProfileState is Result.Success) {
            (userProfileState as Result.Success).data?.let {
                user ->
                fullName = user.fullName
                email = user.email
                phone = user.phone
            }
        }
    }
    
    LaunchedEffect(updateState) {
        if (updateState is Result.Success) {
            snackbarHostState.showSnackbar("Profile updated successfully")
        } else if (updateState is Result.Error) {
            snackbarHostState.showSnackbar((updateState as Result.Error).exception.message ?: "Update failed")
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("My Profile") },
                navigationIcon = {
                    IconButton(onClick = { navController.navigateUp() }) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        },
        snackbarHost = { SnackbarHost(snackbarHostState) }
    ) {
        paddingValues ->
        Box(modifier = Modifier.padding(paddingValues).fillMaxSize()) {
            when (userProfileState) {
                is Result.Loading -> CircularProgressIndicator(modifier = Modifier.align(Alignment.Center))
                is Result.Success -> {
                    Column(
                        modifier = Modifier.fillMaxSize().padding(16.dp).verticalScroll(rememberScrollState())
                    ) {
                        OutlinedTextField(value = fullName, onValueChange = { fullName = it }, label = { Text("Full Name") }, modifier = Modifier.fillMaxWidth())
                        Spacer(modifier = Modifier.height(16.dp))
                        OutlinedTextField(value = email, onValueChange = {}, label = { Text("Email") }, modifier = Modifier.fillMaxWidth(), enabled = false)
                        Spacer(modifier = Modifier.height(16.dp))
                        OutlinedTextField(value = phone, onValueChange = { phone = it }, label = { Text("Phone") }, modifier = Modifier.fillMaxWidth())
                        Spacer(modifier = Modifier.height(32.dp))

                        if (updateState is Result.Loading) {
                            CircularProgressIndicator()
                        } else {
                            Button(
                                onClick = { viewModel.updateProfile(fullName, phone) },
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text("Save Changes")
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))
                        OutlinedButton(
                            onClick = {
                                viewModel.logout()
                                navController.navigate(Screen.Login.route) {
                                    popUpTo(Screen.Home.route) { inclusive = true }
                                }
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("Logout")
                        }
                    }
                }
                is Result.Error -> {
                    Text("Error loading profile", modifier = Modifier.align(Alignment.Center))
                }
            }
        }
    }
}