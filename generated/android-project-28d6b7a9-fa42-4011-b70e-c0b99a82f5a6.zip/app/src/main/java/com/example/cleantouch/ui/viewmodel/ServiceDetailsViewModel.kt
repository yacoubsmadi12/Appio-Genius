package com.example.cleantouch.ui.viewmodel

import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.cleantouch.common.Result
import com.example.cleantouch.data.model.Service
import com.example.cleantouch.data.repository.ServiceRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class ServiceDetailsViewModel @Inject constructor(
    private val serviceRepository: ServiceRepository,
    savedStateHandle: SavedStateHandle
) : ViewModel() {

    private val _service = MutableStateFlow<Result<Service?>>(Result.Loading)
    val service: StateFlow<Result<Service?>> = _service

    private val serviceId: String = savedStateHandle.get<String>("serviceId")!!

    init {
        fetchServiceDetails()
    }

    private fun fetchServiceDetails() {
        viewModelScope.launch {
            _service.value = Result.Loading
            _service.value = serviceRepository.getServiceById(serviceId)
        }
    }
}