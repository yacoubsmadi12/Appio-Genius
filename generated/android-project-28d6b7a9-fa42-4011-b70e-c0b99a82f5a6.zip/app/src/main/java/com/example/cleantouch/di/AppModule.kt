package com.example.cleantouch.di

import com.example.cleantouch.data.repository.AuthRepository
import com.example.cleantouch.data.repository.AuthRepositoryImpl
import com.example.cleantouch.data.repository.BookingRepository
import com.example.cleantouch.data.repository.BookingRepositoryImpl
import com.example.cleantouch.data.repository.ServiceRepository
import com.example.cleantouch.data.repository.ServiceRepositoryImpl
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object AppModule {

    @Provides
    @Singleton
    fun provideFirebaseAuth(): FirebaseAuth = FirebaseAuth.getInstance()

    @Provides
    @Singleton
    fun provideFirebaseFirestore(): FirebaseFirestore = FirebaseFirestore.getInstance()

    @Provides
    @Singleton
    fun provideAuthRepository(auth: FirebaseAuth, firestore: FirebaseFirestore): AuthRepository {
        return AuthRepositoryImpl(auth, firestore)
    }

    @Provides
    @Singleton
    fun provideServiceRepository(firestore: FirebaseFirestore): ServiceRepository {
        return ServiceRepositoryImpl(firestore)
    }

    @Provides
    @Singleton
    fun provideBookingRepository(firestore: FirebaseFirestore, auth: FirebaseAuth): BookingRepository {
        return BookingRepositoryImpl(firestore, auth)
    }
}