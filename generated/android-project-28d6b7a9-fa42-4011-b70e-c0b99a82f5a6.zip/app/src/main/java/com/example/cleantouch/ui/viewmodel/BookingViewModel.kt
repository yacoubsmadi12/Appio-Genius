package com.example.cleantouch.ui.viewmodel

import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.cleantouch.common.Result
import com.example.cleantouch.data.model.Booking
import com.example.cleantouch.data.model.Service
import com.example.cleantouch.data.repository.BookingRepository
import com.example.cleantouch.data.repository.ServiceRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class BookingViewModel @Inject constructor(
    private val serviceRepository: ServiceRepository,
    private val bookingRepository: BookingRepository,
    savedStateHandle: SavedStateHandle
) : ViewModel() {

    private val serviceId: String = savedStateHandle.get<String>("serviceId")!!

    private val _service = MutableStateFlow<Result<Service?>>(Result.Loading)
    val service: StateFlow<Result<Service?>> = _service.asStateFlow()

    private val _bookingState = MutableStateFlow<Result<Unit>?>(null)
    val bookingState: StateFlow<Result<Unit>?> = _bookingState.asStateFlow()

    init {
        fetchServiceDetails()
    }

    private fun fetchServiceDetails() {
        viewModelScope.launch {
            _service.value = serviceRepository.getServiceById(serviceId)
        }
    }

    fun createBooking(date: Long, location: String, notes: String) {
        viewModelScope.launch {
            _bookingState.value = Result.Loading
            val serviceResult = _service.value
            if (serviceResult is Result.Success && serviceResult.data != null) {
                val booking = Booking(
                    serviceId = serviceId,
                    serviceName = serviceResult.data.name,
                    serviceImageUrl = serviceResult.data.imageUrl,
                    bookingDate = date,
                    location = location,
                    notes = notes
                )
                _bookingState.value = bookingRepository.createBooking(booking)
            } else {
                _bookingState.value = Result.Error(Exception("Service details not loaded"))
            }
        }
    }
}