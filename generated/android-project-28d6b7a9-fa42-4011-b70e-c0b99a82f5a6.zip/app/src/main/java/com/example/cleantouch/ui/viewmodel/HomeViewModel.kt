package com.example.cleantouch.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.cleantouch.common.Result
import com.example.cleantouch.data.model.Service
import com.example.cleantouch.data.repository.ServiceRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class HomeViewModel @Inject constructor(
    private val serviceRepository: ServiceRepository
) : ViewModel() {

    private val _services = MutableStateFlow<Result<List<Service>>>(Result.Loading)
    val services: StateFlow<Result<List<Service>>> = _services

    init {
        fetchServices()
    }

    fun fetchServices() {
        viewModelScope.launch {
            _services.value = Result.Loading
            _services.value = serviceRepository.getServices()
        }
    }
}