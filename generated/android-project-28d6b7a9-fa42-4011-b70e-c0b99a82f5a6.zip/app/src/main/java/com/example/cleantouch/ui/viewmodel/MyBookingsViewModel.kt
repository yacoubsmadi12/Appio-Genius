package com.example.cleantouch.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.cleantouch.common.Result
import com.example.cleantouch.data.model.Booking
import com.example.cleantouch.data.repository.BookingRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class MyBookingsViewModel @Inject constructor(
    private val bookingRepository: BookingRepository
) : ViewModel() {

    private val _bookings = MutableStateFlow<Result<List<Booking>>>(Result.Loading)
    val bookings: StateFlow<Result<List<Booking>>> = _bookings.asStateFlow()

    init {
        fetchUserBookings()
    }

    fun fetchUserBookings() {
        viewModelScope.launch {
            _bookings.value = Result.Loading
            _bookings.value = bookingRepository.getUserBookings()
        }
    }
}