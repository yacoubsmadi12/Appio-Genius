package com.example.cleantouch.ui.screens.main

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavController
import com.example.cleantouch.common.Result
import com.example.cleantouch.data.model.Service
import com.example.cleantouch.ui.navigation.Screen
import com.example.cleantouch.ui.viewmodel.BookingViewModel
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BookingScreen(
    navController: NavController,
    viewModel: BookingViewModel = hiltViewModel()
) {
    val serviceState by viewModel.service.collectAsStateWithLifecycle()
    val bookingState by viewModel.bookingState.collectAsStateWithLifecycle()

    var selectedDate by remember { mutableStateOf(System.currentTimeMillis()) }
    var location by remember { mutableStateOf("") }
    var notes by remember { mutableStateOf("") }

    val context = LocalContext.current
    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(bookingState) {
        when (bookingState) {
            is Result.Success -> {
                navController.navigate(Screen.BookingConfirmation.route) {
                    popUpTo(Screen.Home.route)
                }
            }
            is Result.Error -> {
                snackbarHostState.showSnackbar(
                    message = (bookingState as Result.Error).exception.message ?: "Booking failed"
                )
            }
            else -> {}
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Book Service") },
                navigationIcon = {
                    IconButton(onClick = { navController.navigateUp() }) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        },
        snackbarHost = { SnackbarHost(snackbarHostState) }
    ) {
        paddingValues ->
        Box(modifier = Modifier.padding(paddingValues).fillMaxSize()) {
            when (val result = serviceState) {
                is Result.Loading -> CircularProgressIndicator(modifier = Modifier.align(Alignment.Center))
                is Result.Success -> {
                    result.data?.let {
                        service ->
                        BookingForm(
                            service = service,
                            selectedDate = selectedDate,
                            onDateChange = { selectedDate = it },
                            location = location,
                            onLocationChange = { location = it },
                            notes = notes,
                            onNotesChange = { notes = it },
                            onConfirmBooking = {
                                viewModel.createBooking(selectedDate, location, notes)
                            },
                            isBookingInProgress = bookingState is Result.Loading
                        )
                    } ?: Text("Service not found", modifier = Modifier.align(Alignment.Center))
                }
                is Result.Error -> Text(
                    text = result.exception.message ?: "Error",
                    modifier = Modifier.align(Alignment.Center)
                )
            }
        }
    }
}

@Composable
fun BookingForm(
    service: Service,
    selectedDate: Long,
    onDateChange: (Long) -> Unit,
    location: String,
    onLocationChange: (String) -> Unit,
    notes: String,
    onNotesChange: (String) -> Unit,
    onConfirmBooking: () -> Unit,
    isBookingInProgress: Boolean
) {
    val dateFormatter = remember { SimpleDateFormat("EEE, MMM d, yyyy 'at' hh:mm a", Locale.getDefault()) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .verticalScroll(rememberScrollState())
    ) {
        Text(service.name, style = MaterialTheme.typography.headlineMedium)
        Spacer(modifier = Modifier.height(16.dp))

        Text("Selected Date & Time", style = MaterialTheme.typography.titleMedium)
        Text(dateFormatter.format(Date(selectedDate)))
        // In a real app, you would use a DatePickerDialog and TimePickerDialog here.
        // For simplicity, we are using the current time.

        Spacer(modifier = Modifier.height(24.dp))

        OutlinedTextField(
            value = location,
            onValueChange = onLocationChange,
            label = { Text("Location / Address") },
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(modifier = Modifier.height(16.dp))
        OutlinedTextField(
            value = notes,
            onValueChange = onNotesChange,
            label = { Text("Notes (optional)") },
            modifier = Modifier.fillMaxWidth().height(120.dp)
        )
        Spacer(modifier = Modifier.height(32.dp))

        if (isBookingInProgress) {
            CircularProgressIndicator(modifier = Modifier.align(Alignment.CenterHorizontally))
        } else {
            Button(
                onClick = onConfirmBooking,
                modifier = Modifier.fillMaxWidth().height(50.dp),
                enabled = location.isNotBlank()
            ) {
                Text("Confirm Booking")
            }
        }
    }
}