package com.example.cleantouch.data.repository

import com.example.cleantouch.common.Result
import com.example.cleantouch.data.model.Booking
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import kotlinx.coroutines.tasks.await
import javax.inject.Inject

interface BookingRepository {
    suspend fun createBooking(booking: Booking): Result<Unit>
    suspend fun getUserBookings(): Result<List<Booking>>
}

class BookingRepositoryImpl @Inject constructor(
    private val firestore: FirebaseFirestore,
    private val auth: FirebaseAuth
) : BookingRepository {

    override suspend fun createBooking(booking: Booking): Result<Unit> {
        return try {
            val userId = auth.currentUser?.uid ?: return Result.Error(Exception("User not logged in"))
            val newBooking = booking.copy(userId = userId)
            firestore.collection("bookings").add(newBooking).await()
            Result.Success(Unit)
        } catch (e: Exception) {
            Result.Error(e)
        }
    }

    override suspend fun getUserBookings(): Result<List<Booking>> {
        return try {
            val userId = auth.currentUser?.uid ?: return Result.Error(Exception("User not logged in"))
            val snapshot = firestore.collection("bookings")
                .whereEqualTo("userId", userId)
                .orderBy("bookingDate", Query.Direction.DESCENDING)
                .get()
                .await()
            val bookings = snapshot.toObjects(Booking::class.java)
            Result.Success(bookings)
        } catch (e: Exception) {
            Result.Error(e)
        }
    }
}