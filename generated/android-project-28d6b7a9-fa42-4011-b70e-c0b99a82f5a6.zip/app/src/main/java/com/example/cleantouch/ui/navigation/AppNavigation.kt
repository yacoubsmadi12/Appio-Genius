package com.example.cleantouch.ui.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.cleantouch.ui.screens.auth.ForgotPasswordScreen
import com.example.cleantouch.ui.screens.auth.LoginScreen
import com.example.cleantouch.ui.screens.auth.RegisterScreen
import com.example.cleantouch.ui.screens.main.BookingConfirmationScreen
import com.example.cleantouch.ui.screens.main.BookingScreen
import com.example.cleantouch.ui.screens.main.HomeScreen
import com.example.cleantouch.ui.screens.main.MyBookingsScreen
import com.example.cleantouch.ui.screens.main.ProfileScreen
import com.example.cleantouch.ui.screens.main.ServiceDetailsScreen
import com.example.cleantouch.ui.screens.onboarding.OnboardingScreen
import com.example.cleantouch.ui.screens.onboarding.SplashScreen

@Composable
fun AppNavigation() {
    val navController = rememberNavController()

    NavHost(navController = navController, startDestination = Screen.Splash.route) {
        composable(Screen.Splash.route) {
            SplashScreen(navController = navController)
        }
        composable(Screen.Onboarding.route) {
            OnboardingScreen(navController = navController)
        }
        composable(Screen.Login.route) {
            LoginScreen(navController = navController)
        }
        composable(Screen.Register.route) {
            RegisterScreen(navController = navController)
        }
        composable(Screen.ForgotPassword.route) {
            ForgotPasswordScreen(navController = navController)
        }
        composable(Screen.Home.route) {
            HomeScreen(navController = navController)
        }
        composable(
            route = Screen.ServiceDetails.route + "/{serviceId}",
            arguments = listOf(navArgument("serviceId") { type = NavType.StringType })
        ) {
            ServiceDetailsScreen(navController = navController)
        }
        composable(
            route = Screen.Booking.route + "/{serviceId}",
            arguments = listOf(navArgument("serviceId") { type = NavType.StringType })
        ) {
            BookingScreen(navController = navController)
        }
        composable(Screen.BookingConfirmation.route) {
            BookingConfirmationScreen(navController = navController)
        }
        composable(Screen.MyBookings.route) {
            MyBookingsScreen(navController = navController)
        }
        composable(Screen.Profile.route) {
            ProfileScreen(navController = navController)
        }
    }
}