package com.example.cleantouch.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.cleantouch.common.Result
import com.example.cleantouch.data.model.User
import com.example.cleantouch.data.repository.AuthRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class ProfileViewModel @Inject constructor(
    private val authRepository: AuthRepository
) : ViewModel() {

    private val _userProfile = MutableStateFlow<Result<User?>>(Result.Loading)
    val userProfile: StateFlow<Result<User?>> = _userProfile.asStateFlow()

    private val _updateState = MutableStateFlow<Result<Unit>?>(null)
    val updateState: StateFlow<Result<Unit>?> = _updateState.asStateFlow()

    init {
        loadUserProfile()
    }

    fun loadUserProfile() {
        viewModelScope.launch {
            _userProfile.value = authRepository.getUserProfile()
        }
    }

    fun updateProfile(fullName: String, phone: String) {
        viewModelScope.launch {
            _updateState.value = Result.Loading
            val currentUserResult = _userProfile.value
            if (currentUserResult is Result.Success && currentUserResult.data != null) {
                val updatedUser = currentUserResult.data.copy(fullName = fullName, phone = phone)
                _updateState.value = authRepository.updateUserProfile(updatedUser)
                // Refresh profile data on success
                if (_updateState.value is Result.Success) {
                    loadUserProfile()
                }
            } else {
                _updateState.value = Result.Error(Exception("User not loaded"))
            }
        }
    }

    fun logout() {
        viewModelScope.launch {
            authRepository.logout()
        }
    }
}