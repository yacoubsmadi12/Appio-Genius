package com.example.cleantouch.ui.screens.profile

import androidx.lifecycle.ViewModel
import com.example.cleantouch.data.model.AppUser
import com.example.cleantouch.data.repository.AuthRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject

@HiltViewModel
class ProfileViewModel @Inject constructor(
    private val authRepository: AuthRepository
) : ViewModel() {

    val currentUser: AppUser? = authRepository.currentUser

    fun logout() {
        authRepository.logout()
    }
}