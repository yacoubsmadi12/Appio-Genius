package com.example.cleantouch.ui.screens.splash

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import com.example.cleantouch.data.repository.AuthRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject

@HiltViewModel
class SplashViewModel @Inject constructor(
    private val authRepository: AuthRepository
) : ViewModel() {

    var isUserAuthenticated by mutableStateOf<Boolean?>(null)
        private set

    fun checkAuthState() {
        isUserAuthenticated = authRepository.currentUser != null
    }
}