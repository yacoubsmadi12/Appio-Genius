package com.example.cleantouch.data.repository

import com.example.cleantouch.data.model.Booking
import com.example.cleantouch.util.Resource
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import kotlinx.coroutines.tasks.await
import javax.inject.Inject

interface BookingRepository {
    suspend fun createBooking(booking: Booking): Resource<Unit>
    suspend fun getUserBookings(): Resource<List<Booking>>
}

class BookingRepositoryImpl @Inject constructor(
    private val firestore: FirebaseFirestore,
    private val auth: FirebaseAuth
) : BookingRepository {

    override suspend fun createBooking(booking: Booking): Resource<Unit> {
        return try {
            val userId = auth.currentUser?.uid ?: return Resource.Error("User not logged in.")
            firestore.collection("bookings").add(booking.copy(userId = userId)).await()
            Resource.Success(Unit)
        } catch (e: Exception) {
            Resource.Error(e.message ?: "Failed to create booking.")
        }
    }

    override suspend fun getUserBookings(): Resource<List<Booking>> {
        return try {
            val userId = auth.currentUser?.uid ?: return Resource.Error("User not logged in.")
            val snapshot = firestore.collection("bookings")
                .whereEqualTo("userId", userId)
                .orderBy("bookingDate", Query.Direction.DESCENDING)
                .get()
                .await()
            val bookings = snapshot.toObjects(Booking::class.java)
            Resource.Success(bookings)
        } catch (e: Exception) {
            Resource.Error(e.message ?: "Failed to fetch bookings.")
        }
    }
}