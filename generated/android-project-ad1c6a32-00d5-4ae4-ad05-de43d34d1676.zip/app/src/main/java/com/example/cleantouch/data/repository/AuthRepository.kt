package com.example.cleantouch.data.repository

import com.example.cleantouch.data.model.AppUser
import com.example.cleantouch.util.Resource
import com.google.firebase.auth.AuthResult
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.tasks.await
import javax.inject.Inject

interface AuthRepository {
    val currentUser: AppUser?
    suspend fun login(email: String, password: String): Resource<AuthResult>
    suspend fun signUp(email: String, password: String, displayName: String): Resource<AuthResult>
    fun logout()
}

class AuthRepositoryImpl @Inject constructor(
    private val auth: FirebaseAuth,
    private val firestore: FirebaseFirestore
) : AuthRepository {

    override val currentUser: AppUser?
        get() = auth.currentUser?.let { AppUser(uid = it.uid, email = it.email ?: "", displayName = it.displayName ?: "") }

    override suspend fun login(email: String, password: String): Resource<AuthResult> {
        return try {
            val result = auth.signInWithEmailAndPassword(email, password).await()
            Resource.Success(result)
        } catch (e: Exception) {
            Resource.Error(e.message ?: "An unknown error occurred.")
        }
    }

    override suspend fun signUp(email: String, password: String, displayName: String): Resource<AuthResult> {
        return try {
            val result = auth.createUserWithEmailAndPassword(email, password).await()
            val firebaseUser = result.user
            if (firebaseUser != null) {
                val appUser = AppUser(uid = firebaseUser.uid, email = email, displayName = displayName)
                firestore.collection("users").document(firebaseUser.uid).set(appUser).await()
                Resource.Success(result)
            } else {
                Resource.Error("User creation failed.")
            }
        } catch (e: Exception) {
            Resource.Error(e.message ?: "An unknown error occurred.")
        }
    }

    override fun logout() {
        auth.signOut()
    }
}