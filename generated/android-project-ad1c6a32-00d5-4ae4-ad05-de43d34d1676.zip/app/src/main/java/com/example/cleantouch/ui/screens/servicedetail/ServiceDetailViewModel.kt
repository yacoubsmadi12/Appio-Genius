package com.example.cleantouch.ui.screens.servicedetail

import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.cleantouch.data.model.CleaningService
import com.example.cleantouch.data.repository.ServiceRepository
import com.example.cleantouch.util.Resource
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

sealed class ServiceDetailState {
    object Loading : ServiceDetailState()
    class Success(val service: CleaningService) : ServiceDetailState()
    class Error(val message: String) : ServiceDetailState()
}

@HiltViewModel
class ServiceDetailViewModel @Inject constructor(
    private val serviceRepository: ServiceRepository,
    savedStateHandle: SavedStateHandle
) : ViewModel() {

    private val _serviceDetailState = MutableStateFlow<ServiceDetailState>(ServiceDetailState.Loading)
    val serviceDetailState: StateFlow<ServiceDetailState> = _serviceDetailState

    init {
        val serviceId = savedStateHandle.get<String>("serviceId")
        if (serviceId != null) {
            loadServiceDetails(serviceId)
        }
    }

    private fun loadServiceDetails(serviceId: String) {
        viewModelScope.launch {
            _serviceDetailState.value = ServiceDetailState.Loading
            when (val result = serviceRepository.getServiceById(serviceId)) {
                is Resource.Success -> {
                    result.data?.let {
                        _serviceDetailState.value = ServiceDetailState.Success(it)
                    }
                }
                is Resource.Error -> {
                    _serviceDetailState.value = ServiceDetailState.Error(result.message ?: "Error loading details")
                }
                else -> {}
            }
        }
    }
}