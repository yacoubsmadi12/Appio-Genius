package com.example.cleantouch.ui.screens.home

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.cleantouch.data.model.CleaningService
import com.example.cleantouch.data.repository.ServiceRepository
import com.example.cleantouch.util.Resource
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

sealed class HomeState {
    object Loading : HomeState()
    class Success(val services: List<CleaningService>) : HomeState()
    class Error(val message: String) : HomeState()
}

@HiltViewModel
class HomeViewModel @Inject constructor(
    private val serviceRepository: ServiceRepository
) : ViewModel() {

    private val _homeState = MutableStateFlow<HomeState>(HomeState.Loading)
    val homeState: StateFlow<HomeState> = _homeState

    init {
        loadServices()
    }

    fun loadServices() {
        viewModelScope.launch {
            _homeState.value = HomeState.Loading
            when (val result = serviceRepository.getAllServices()) {
                is Resource.Success -> {
                    _homeState.value = HomeState.Success(result.data ?: emptyList())
                }
                is Resource.Error -> {
                    _homeState.value = HomeState.Error(result.message ?: "Failed to load services")
                }
                else -> {}
            }
        }
    }
}