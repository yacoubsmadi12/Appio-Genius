package com.example.cleantouch.navigation

sealed class Screen(val route: String) {
    object Splash : Screen("splash_screen")
    object Login : Screen("login_screen")
    object SignUp : Screen("signup_screen")
    object Home : Screen("home_screen")
    object ServiceDetail : Screen("service_detail_screen/{serviceId}") {
        fun createRoute(serviceId: String) = "service_detail_screen/$serviceId"
    }
    object Booking : Screen("booking_screen/{serviceId}") {
        fun createRoute(serviceId: String) = "booking_screen/$serviceId"
    }
    object Reservations : Screen("reservations_screen")
    object Profile : Screen("profile_screen")
}