package com.example.cleantouch.data.model

import com.google.firebase.firestore.DocumentId

data class CleaningService(
    @DocumentId
    val id: String = "",
    val name: String = "",
    val description: String = "",
    val price: Double = 0.0,
    val imageUrl: String = "",
    val category: String = ""
)