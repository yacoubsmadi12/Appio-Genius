package com.example.cleantouch.ui.theme

import androidx.compose.ui.graphics.Color

val PrimaryBlue = Color(0xFF007BFF)
val PrimaryVariantBlue = Color(0xFF0056b3)
val SecondaryGreen = Color(0xFF28A745)
val BackgroundWhite = Color(0xFFFFFFFF)
val SurfaceWhite = Color(0xFFFFFFFF)
val TextBlack = Color(0xFF212529)
val TextGray = Color(0xFF6c757d)