package com.example.cleantouch.ui.screens.reservations

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.cleantouch.data.model.Booking
import com.example.cleantouch.data.repository.BookingRepository
import com.example.cleantouch.util.Resource
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

sealed class ReservationsState {
    object Loading : ReservationsState()
    class Success(val bookings: List<Booking>) : ReservationsState()
    class Error(val message: String) : ReservationsState()
}

@HiltViewModel
class ReservationsViewModel @Inject constructor(
    private val bookingRepository: BookingRepository
) : ViewModel() {

    private val _reservationsState = MutableStateFlow<ReservationsState>(ReservationsState.Loading)
    val reservationsState: StateFlow<ReservationsState> = _reservationsState

    init {
        loadUserBookings()
    }

    fun loadUserBookings() {
        viewModelScope.launch {
            _reservationsState.value = ReservationsState.Loading
            when (val result = bookingRepository.getUserBookings()) {
                is Resource.Success -> {
                    _reservationsState.value = ReservationsState.Success(result.data ?: emptyList())
                }
                is Resource.Error -> {
                    _reservationsState.value = ReservationsState.Error(result.message ?: "Failed to load bookings")
                }
                else -> {}
            }
        }
    }
}