package com.example.cleantouch.ui.screens.booking

import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.cleantouch.data.model.Booking
import com.example.cleantouch.data.model.CleaningService
import com.example.cleantouch.data.repository.BookingRepository
import com.example.cleantouch.data.repository.ServiceRepository
import com.example.cleantouch.util.Resource
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import java.util.Date
import javax.inject.Inject

sealed class BookingScreenState {
    object Idle : BookingScreenState()
    object Loading : BookingScreenState()
    object BookingSuccess : BookingScreenState()
    class Error(val message: String) : BookingScreenState()
}

@HiltViewModel
class BookingViewModel @Inject constructor(
    private val bookingRepository: BookingRepository,
    private val serviceRepository: ServiceRepository,
    savedStateHandle: SavedStateHandle
) : ViewModel() {

    private val _service = MutableStateFlow<CleaningService?>(null)
    val service: StateFlow<CleaningService?> = _service

    private val _bookingState = MutableStateFlow<BookingScreenState>(BookingScreenState.Idle)
    val bookingState: StateFlow<BookingScreenState> = _bookingState

    private val serviceId: String? = savedStateHandle.get("serviceId")

    init {
        serviceId?.let { fetchServiceDetails(it) }
    }

    private fun fetchServiceDetails(id: String) {
        viewModelScope.launch {
            val result = serviceRepository.getServiceById(id)
            if (result is Resource.Success) {
                _service.value = result.data
            }
        }
    }

    fun createBooking(date: Date) {
        val currentService = _service.value
        if (currentService == null || serviceId == null) {
            _bookingState.value = BookingScreenState.Error("Service details not found.")
            return
        }

        val newBooking = Booking(
            serviceId = serviceId,
            serviceName = currentService.name,
            bookingDate = date,
            price = currentService.price,
            status = "Pending"
        )

        viewModelScope.launch {
            _bookingState.value = BookingScreenState.Loading
            when(val result = bookingRepository.createBooking(newBooking)) {
                is Resource.Success -> _bookingState.value = BookingScreenState.BookingSuccess
                is Resource.Error -> _bookingState.value = BookingScreenState.Error(result.message ?: "Booking failed.")
                else -> {}
            }
        }
    }
}