package com.example.cleantouch.data.model

import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.ServerTimestamp
import java.util.Date

data class Booking(
    @DocumentId
    val id: String = "",
    val userId: String = "",
    val serviceId: String = "",
    val serviceName: String = "",
    val bookingDate: Date = Date(),
    @ServerTimestamp
    val createdAt: Date? = null,
    val status: String = "Pending", // e.g., Pending, Confirmed, Completed, Cancelled
    val price: Double = 0.0
)