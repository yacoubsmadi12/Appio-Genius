package com.example.cleantouch.ui.screens.booking

import android.widget.Toast
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavController
import com.example.cleantouch.navigation.Screen
import java.util.Date

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BookingScreen(
    navController: NavController,
    serviceId: String?,
    viewModel: BookingViewModel = hiltViewModel()
) {
    val service by viewModel.service.collectAsState()
    val bookingState by viewModel.bookingState.collectAsState()
    val context = LocalContext.current

    var selectedDate by remember { mutableStateOf<Date?>(null) }

    LaunchedEffect(bookingState) {
        when (bookingState) {
            is BookingScreenState.BookingSuccess -> {
                Toast.makeText(context, "Booking Successful!", Toast.LENGTH_LONG).show()
                navController.navigate(Screen.Reservations.route) {
                    popUpTo(Screen.Home.route)
                }
            }
            is BookingScreenState.Error -> {
                Toast.makeText(context, (bookingState as BookingScreenState.Error).message, Toast.LENGTH_SHORT).show()
            }
            else -> {}
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Book a Service") },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { paddingValues ->
        if (service == null) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator()
            }
        } else {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues)
                    .padding(16.dp)
            ) {
                Text("Booking: ${service?.name}", style = MaterialTheme.typography.headlineSmall)
                Spacer(modifier = Modifier.height(8.dp))
                Text("Price: $${service?.price}", style = MaterialTheme.typography.titleMedium)
                Spacer(modifier = Modifier.height(24.dp))
                
                // A real app would use a DatePicker component here.
                // For simplicity, we use a button to simulate date selection.
                Button(onClick = { selectedDate = Date() }) {
                    Text(if (selectedDate == null) "Select Date & Time" else selectedDate.toString())
                }

                Spacer(modifier = Modifier.weight(1f))

                Button(
                    onClick = { 
                        selectedDate?.let { viewModel.createBooking(it) }
                            ?: Toast.makeText(context, "Please select a date", Toast.LENGTH_SHORT).show()
                    },
                    enabled = bookingState != BookingScreenState.Loading && selectedDate != null,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Confirm Booking")
                }
                if (bookingState == BookingScreenState.Loading) {
                    CircularProgressIndicator(modifier = Modifier.padding(top = 16.dp).align(Alignment.CenterHorizontally))
                }
            }
        }
    }
}