package com.example.cleantouch.data.repository

import com.example.cleantouch.data.model.CleaningService
import com.example.cleantouch.util.Resource
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.tasks.await
import javax.inject.Inject

interface ServiceRepository {
    suspend fun getAllServices(): Resource<List<CleaningService>>
    suspend fun getServiceById(serviceId: String): Resource<CleaningService>
}

class ServiceRepositoryImpl @Inject constructor(
    private val firestore: FirebaseFirestore
) : ServiceRepository {

    override suspend fun getAllServices(): Resource<List<CleaningService>> {
        return try {
            val snapshot = firestore.collection("services").get().await()
            val services = snapshot.toObjects(CleaningService::class.java)
            Resource.Success(services)
        } catch (e: Exception) {
            Resource.Error(e.message ?: "Failed to fetch services.")
        }
    }

    override suspend fun getServiceById(serviceId: String): Resource<CleaningService> {
        return try {
            val document = firestore.collection("services").document(serviceId).get().await()
            val service = document.toObject(CleaningService::class.java)
            if (service != null) {
                Resource.Success(service)
            } else {
                Resource.Error("Service not found.")
            }
        } catch (e: Exception) {
            Resource.Error(e.message ?: "Failed to fetch service details.")
        }
    }
}