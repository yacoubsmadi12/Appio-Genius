package com.example.cleantouch.di

import com.example.cleantouch.data.repository.*
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object AppModule {

    @Provides
    @Singleton
    fun provideAuthRepository(auth: FirebaseAuth, firestore: FirebaseFirestore): AuthRepository {
        return AuthRepositoryImpl(auth, firestore)
    }

    @Provides
    @Singleton
    fun provideServiceRepository(firestore: FirebaseFirestore): ServiceRepository {
        return ServiceRepositoryImpl(firestore)
    }

    @Provides
    @Singleton
    fun provideBookingRepository(firestore: FirebaseFirestore, auth: FirebaseAuth): BookingRepository {
        return BookingRepositoryImpl(firestore, auth)
    }

}