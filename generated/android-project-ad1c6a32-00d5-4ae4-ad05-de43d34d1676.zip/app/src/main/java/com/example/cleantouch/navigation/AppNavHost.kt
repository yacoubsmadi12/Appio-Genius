package com.example.cleantouch.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.cleantouch.ui.screens.auth.LoginScreen
import com.example.cleantouch.ui.screens.auth.SignUpScreen
import com.example.cleantouch.ui.screens.booking.BookingScreen
import com.example.cleantouch.ui.screens.home.HomeScreen
import com.example.cleantouch.ui.screens.profile.ProfileScreen
import com.example.cleantouch.ui.screens.reservations.ReservationsScreen
import com.example.cleantouch.ui.screens.servicedetail.ServiceDetailScreen
import com.example.cleantouch.ui.screens.splash.SplashScreen

@Composable
fun AppNavHost(
    navController: NavHostController = rememberNavController(),
    startDestination: String = Screen.Splash.route
) {
    NavHost(navController = navController, startDestination = startDestination) {
        composable(Screen.Splash.route) {
            SplashScreen(navController = navController)
        }
        composable(Screen.Login.route) {
            LoginScreen(navController = navController)
        }
        composable(Screen.SignUp.route) {
            SignUpScreen(navController = navController)
        }
        composable(Screen.Home.route) {
            HomeScreen(navController = navController)
        }
        composable(Screen.ServiceDetail.route) { backStackEntry ->
            val serviceId = backStackEntry.arguments?.getString("serviceId")
            ServiceDetailScreen(navController = navController, serviceId = serviceId)
        }
        composable(Screen.Booking.route) { backStackEntry ->
            val serviceId = backStackEntry.arguments?.getString("serviceId")
            BookingScreen(navController = navController, serviceId = serviceId)
        }
        composable(Screen.Reservations.route) {
            ReservationsScreen(navController = navController)
        }
        composable(Screen.Profile.route) {
            ProfileScreen(navController = navController)
        }
    }
}