package com.example.cleantouch.data.model

data class AppUser(
    val uid: String = "",
    val email: String = "",
    val displayName: String = "",
    val phoneNumber: String? = null,
    val address: String? = null
)