package com.example.cleantouch.ui.screens.reservations

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.cleantouch.data.model.Booking
import com.example.cleantouch.data.repository.AuthRepository
import com.example.cleantouch.data.repository.StorageRepository
import com.example.cleantouch.util.Resource
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class ReservationsViewModel @Inject constructor(
    private val storageRepository: StorageRepository,
    private val authRepository: AuthRepository
) : ViewModel() {

    private val _bookingsState = MutableStateFlow<Resource<List<Booking>>>(Resource.Loading())
    val bookingsState: StateFlow<Resource<List<Booking>>> = _bookingsState

    init {
        loadMyBookings()
    }

    fun loadMyBookings() {
        viewModelScope.launch {
            authRepository.currentUserId?.let {
                _bookingsState.value = Resource.Loading()
                _bookingsState.value = storageRepository.getMyBookings(it)
            }
        }
    }
}