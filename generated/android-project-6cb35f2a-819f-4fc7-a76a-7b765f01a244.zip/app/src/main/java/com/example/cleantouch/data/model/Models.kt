package com.example.cleantouch.data.model

import com.google.firebase.firestore.ServerTimestamp
import java.util.Date

data class User(
    val uid: String = "",
    val displayName: String = "",
    val email: String = ""
)

data class ServiceCategory(
    val id: String = "",
    val name: String = "",
    val description: String = "",
    val iconUrl: String = ""
)

data class Booking(
    val id: String = "",
    val userId: String = "",
    val serviceName: String = "",
    val serviceId: String = "",
    @ServerTimestamp
    val bookingDate: Date? = null,
    val requestedDate: Long = 0L,
    val status: String = "Pending", // Pending, Confirmed, Completed, Cancelled
    val notes: String = ""
)