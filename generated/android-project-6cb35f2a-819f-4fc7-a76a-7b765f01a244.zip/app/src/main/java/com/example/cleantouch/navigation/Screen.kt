package com.example.cleantouch.navigation

sealed class Screen(val route: String) {
    object Login : Screen("login_screen")
    object SignUp : Screen("signup_screen")
    object Home : Screen("home_screen")
    object Reservations : Screen("reservations_screen")
    object Profile : Screen("profile_screen")
    object Booking : Screen("booking_screen/{serviceId}/{serviceName}") {
        fun createRoute(serviceId: String, serviceName: String) = "booking_screen/$serviceId/$serviceName"
    }
    
    // Graph routes
    object AuthGraph: Screen("auth_graph")
    object MainGraph: Screen("main_graph")
}
