package com.example.cleantouch.ui.screens.home

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.cleantouch.data.model.ServiceCategory
import com.example.cleantouch.data.repository.StorageRepository
import com.example.cleantouch.util.Resource
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class HomeViewModel @Inject constructor(
    private val storageRepository: StorageRepository
) : ViewModel() {

    private val _servicesState = MutableStateFlow<Resource<List<ServiceCategory>>>(Resource.Loading())
    val servicesState: StateFlow<Resource<List<ServiceCategory>>> = _servicesState

    init {
        loadServices()
    }

    private fun loadServices() {
        viewModelScope.launch {
            _servicesState.value = Resource.Loading()
            _servicesState.value = storageRepository.getServiceCategories()
        }
    }
}