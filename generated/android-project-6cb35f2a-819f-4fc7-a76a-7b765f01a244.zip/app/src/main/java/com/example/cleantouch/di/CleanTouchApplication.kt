package com.example.cleantouch.di

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class CleanTouchApplication : Application()