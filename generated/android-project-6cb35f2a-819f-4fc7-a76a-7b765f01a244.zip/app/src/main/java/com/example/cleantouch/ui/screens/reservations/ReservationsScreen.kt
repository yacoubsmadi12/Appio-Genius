package com.example.cleantouch.ui.screens.reservations

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.example.cleantouch.data.model.Booking
import com.example.cleantouch.util.Resource
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun ReservationsScreen(viewModel: ReservationsViewModel = hiltViewModel()) {
    val bookingsState by viewModel.bookingsState.collectAsState()

    Scaffold(
        topBar = { TopAppBar(title = { Text("My Reservations") }) }
    ) {
        Box(modifier = Modifier.fillMaxSize().padding(it), contentAlignment = Alignment.Center) {
            when (val state = bookingsState) {
                is Resource.Loading -> CircularProgressIndicator()
                is Resource.Success -> {
                    val bookings = state.data
                    if (bookings.isNullOrEmpty()) {
                        Text("You have no bookings yet.")
                    } else {
                        LazyColumn(modifier = Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp)) {
                            items(bookings) { booking ->
                                BookingItem(booking = booking)
                                Spacer(modifier = Modifier.height(8.dp))
                            }
                        }
                    }
                }
                is Resource.Error -> {
                    Text(state.message ?: "Failed to load bookings.")
                }
                else -> {}
            }
        }
    }
}

@Composable
fun BookingItem(booking: Booking) {
    val sdf = SimpleDateFormat("EEE, MMM d, yyyy", Locale.getDefault())
    val dateString = sdf.format(Date(booking.requestedDate))

    Card(
        modifier = Modifier.fillMaxWidth(),
        elevation = CardDefaults.cardElevation(2.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(booking.serviceName, style = MaterialTheme.typography.titleMedium)
            Spacer(modifier = Modifier.height(4.dp))
            Text("Date: $dateString", style = MaterialTheme.typography.bodyMedium)
            Text("Status: ${booking.status}", style = MaterialTheme.typography.bodyMedium)
            if (booking.notes.isNotBlank()) {
                 Text("Notes: ${booking.notes}", style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}
