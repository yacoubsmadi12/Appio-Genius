package com.example.cleantouch.data.repository

import com.example.cleantouch.data.model.Booking
import com.example.cleantouch.data.model.ServiceCategory
import com.example.cleantouch.data.model.User
import com.example.cleantouch.util.Resource
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.tasks.await
import javax.inject.Inject

interface StorageRepository {
    suspend fun getUser(userId: String): Resource<User>
    suspend fun getServiceCategories(): Resource<List<ServiceCategory>>
    suspend fun getMyBookings(userId: String): Resource<List<Booking>>
    suspend fun addBooking(booking: Booking): Resource<Unit>
}

class StorageRepositoryImpl @Inject constructor(
    private val firestore: FirebaseFirestore,
    private val auth: FirebaseAuth
) : StorageRepository {

    override suspend fun getUser(userId: String): Resource<User> {
        return try {
            val document = firestore.collection("users").document(userId).get().await()
            val user = document.toObject(User::class.java)
            Resource.Success(user)
        } catch (e: Exception) {
            Resource.Error(e.message ?: "An unknown error occurred.")
        }
    }

    override suspend fun getServiceCategories(): Resource<List<ServiceCategory>> {
        return try {
            // In a real app, this data would come from Firestore.
            // For this example, we'll return a static list.
            val categories = listOf(
                ServiceCategory("1", "Carpet Cleaning", "Deep clean for all types of carpets.", ""),
                ServiceCategory("2", "Car Wash", "Exterior and interior car cleaning.", ""),
                ServiceCategory("3", "Garden Maintenance", "Lawn mowing, hedge trimming, and more.", ""),
                ServiceCategory("4", "Kitchen Deep Clean", "A thorough clean of your kitchen appliances and surfaces.", "")
            )
            Resource.Success(categories)
        } catch (e: Exception) {
            Resource.Error(e.message ?: "Failed to load services.")
        }
    }

    override suspend fun getMyBookings(userId: String): Resource<List<Booking>> {
        return try {
            val snapshot = firestore.collection("bookings")
                .whereEqualTo("userId", userId)
                .get()
                .await()
            val bookings = snapshot.toObjects(Booking::class.java)
            Resource.Success(bookings)
        } catch (e: Exception) {
            Resource.Error(e.message ?: "Failed to load bookings.")
        }
    }

    override suspend fun addBooking(booking: Booking): Resource<Unit> {
        return try {
            val documentRef = firestore.collection("bookings").document()
            val newBooking = booking.copy(id = documentRef.id)
            documentRef.set(newBooking).await()
            Resource.Success(Unit)
        } catch (e: Exception) {
            Resource.Error(e.message ?: "Failed to create booking.")
        }
    }
}