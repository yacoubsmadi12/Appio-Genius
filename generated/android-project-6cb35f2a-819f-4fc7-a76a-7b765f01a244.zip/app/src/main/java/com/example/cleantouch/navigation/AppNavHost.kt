package com.example.cleantouch.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.navigation
import com.example.cleantouch.ui.screens.auth.LoginScreen
import com.example.cleantouch.ui.screens.auth.SignUpScreen
import com.example.cleantouch.ui.screens.booking.BookingScreen
import com.example.cleantouch.ui.screens.home.HomeScreen
import com.example.cleantouch.ui.screens.profile.ProfileScreen
import com.example.cleantouch.ui.screens.reservations.ReservationsScreen

@Composable
fun AppNavHost(navController: NavHostController, startDestination: String) {
    NavHost(navController = navController, startDestination = startDestination) {
        navigation(startDestination = Screen.Login.route, route = Screen.AuthGraph.route) {
            composable(Screen.Login.route) {
                LoginScreen(onLoginSuccess = {
                    navController.navigate(Screen.MainGraph.route) {
                        popUpTo(Screen.AuthGraph.route) { inclusive = true }
                    }
                }, onNavigateToSignUp = {
                    navController.navigate(Screen.SignUp.route)
                })
            }
            composable(Screen.SignUp.route) {
                SignUpScreen(onSignUpSuccess = {
                     navController.navigate(Screen.MainGraph.route) {
                        popUpTo(Screen.AuthGraph.route) { inclusive = true }
                    }
                }, onNavigateToLogin = {
                    navController.popBackStack()
                })
            }
        }

        navigation(startDestination = Screen.Home.route, route = Screen.MainGraph.route) {
            composable(Screen.Home.route) {
                HomeScreen(navController = navController)
            }
            composable(Screen.Reservations.route) {
                ReservationsScreen()
            }
            composable(Screen.Profile.route) {
                ProfileScreen(onLogout = {
                    navController.navigate(Screen.AuthGraph.route) {
                        popUpTo(Screen.MainGraph.route) { inclusive = true }
                    }
                })
            }
            composable(Screen.Booking.route) { backStackEntry ->
                val serviceId = backStackEntry.arguments?.getString("serviceId") ?: ""
                val serviceName = backStackEntry.arguments?.getString("serviceName") ?: ""
                BookingScreen(serviceId = serviceId, serviceName = serviceName) {
                    navController.popBackStack()
                }
            }
        }
    }
}