package com.example.cleantouch.ui.screens.booking

import android.widget.Toast
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BookingScreen(
    serviceId: String,
    serviceName: String,
    viewModel: BookingViewModel = hiltViewModel(),
    onBookingSuccess: () -> Unit
) {
    val context = LocalContext.current
    var notes by remember { mutableStateOf("") }
    val bookingState by viewModel.bookingState.collectAsState()

    val datePickerState = rememberDatePickerState()
    var showDatePicker by remember { mutableStateOf(false) }

    LaunchedEffect(bookingState) {
        when (val state = bookingState) {
            is BookingUiState.Success -> {
                Toast.makeText(context, "Booking Successful!", Toast.LENGTH_SHORT).show()
                viewModel.resetState()
                onBookingSuccess()
            }
            is BookingUiState.Error -> {
                Toast.makeText(context, state.message, Toast.LENGTH_SHORT).show()
                 viewModel.resetState()
            }
            else -> {}
        }
    }

    Scaffold(
        topBar = { TopAppBar(title = { Text("Book: $serviceName") }) }
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(it)
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text("Select Date and Time", style = MaterialTheme.typography.titleLarge)
            Spacer(modifier = Modifier.height(16.dp))

            Button(onClick = { showDatePicker = true }) {
                Text(if (datePickerState.selectedDateMillis != null) "Change Date" else "Select Date")
            }

            datePickerState.selectedDateMillis?.let {
                 Text("Selected: ${java.text.SimpleDateFormat.getDateInstance().format(it)}", modifier = Modifier.padding(top = 8.dp))
            }

            Spacer(modifier = Modifier.height(16.dp))

            OutlinedTextField(
                value = notes,
                onValueChange = { notes = it },
                label = { Text("Additional Notes (optional)") },
                modifier = Modifier.fillMaxWidth().height(120.dp)
            )
            Spacer(modifier = Modifier.height(24.dp))

            if (bookingState is BookingUiState.Loading) {
                CircularProgressIndicator()
            } else {
                Button(
                    onClick = {
                        val selectedDate = datePickerState.selectedDateMillis
                        if (selectedDate != null) {
                            viewModel.createBooking(serviceId, serviceName, selectedDate, notes)
                        } else {
                            Toast.makeText(context, "Please select a date", Toast.LENGTH_SHORT).show()
                        }
                    },
                    modifier = Modifier.fillMaxWidth(),
                    enabled = datePickerState.selectedDateMillis != null
                ) {
                    Text("Confirm Booking")
                }
            }
        }
    }

    if (showDatePicker) {
        DatePickerDialog(
            onDismissRequest = { showDatePicker = false },
            confirmButton = {
                TextButton(onClick = { showDatePicker = false }) {
                    Text("OK")
                }
            },
            dismissButton = {
                TextButton(onClick = { showDatePicker = false }) {
                    Text("Cancel")
                }
            }
        ) {
            DatePicker(state = datePickerState)
        }
    }
}