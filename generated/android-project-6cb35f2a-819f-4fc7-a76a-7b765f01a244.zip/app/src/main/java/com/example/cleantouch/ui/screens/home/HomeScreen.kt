package com.example.cleantouch.ui.screens.home

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CleaningServices
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavController
import com.example.cleantouch.data.model.ServiceCategory
import com.example.cleantouch.navigation.Screen
import com.example.cleantouch.util.Resource

@Composable
fun HomeScreen(
    viewModel: HomeViewModel = hiltViewModel(),
    navController: NavController
) {
    val servicesState by viewModel.servicesState.collectAsState()

    Scaffold(
        topBar = {
            TopAppBar(title = { Text("Select a Service") })
        }
    ) {\ padding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
            contentAlignment = Alignment.Center
        ) {
            when (servicesState) {
                is Resource.Loading -> CircularProgressIndicator()
                is Resource.Success -> {
                    val services = (servicesState as Resource.Success<List<ServiceCategory>>).data
                    if (services != null) {
                        LazyColumn(modifier = Modifier.fillMaxSize()) {
                            items(services) { service ->
                                ServiceCategoryItem(service = service) {
                                    navController.navigate(Screen.Booking.createRoute(service.id, service.name))
                                }
                            }
                        }
                    }
                }
                is Resource.Error -> {
                    Text(text = (servicesState as Resource.Error).message ?: "Error loading services")
                }
                else -> {}
            }
        }
    }
}

@Composable
fun ServiceCategoryItem(service: ServiceCategory, onClick: () -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp)
            .clickable { onClick() },
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
    ) {
        Row(
            modifier = Modifier
                .padding(16.dp)
                .fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = Icons.Default.CleaningServices,
                contentDescription = service.name,
                modifier = Modifier.size(40.dp)
            )
            Spacer(modifier = Modifier.width(16.dp))
            Column {
                Text(text = service.name, style = MaterialTheme.typography.titleLarge)
                Text(text = service.description, style = MaterialTheme.typography.bodyMedium)
            }
        }
    }
}