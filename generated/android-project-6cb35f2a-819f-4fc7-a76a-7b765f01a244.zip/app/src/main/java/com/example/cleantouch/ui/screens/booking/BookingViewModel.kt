package com.example.cleantouch.ui.screens.booking

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.cleantouch.data.model.Booking
import com.example.cleantouch.data.repository.AuthRepository
import com.example.cleantouch.data.repository.StorageRepository
import com.example.cleantouch.util.Resource
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

sealed class BookingUiState {
    object Idle : BookingUiState()
    object Loading : BookingUiState()
    object Success : BookingUiState()
    data class Error(val message: String) : BookingUiState()
}

@HiltViewModel
class BookingViewModel @Inject constructor(
    private val storageRepository: StorageRepository,
    private val authRepository: AuthRepository
) : ViewModel() {

    private val _bookingState = MutableStateFlow<BookingUiState>(BookingUiState.Idle)
    val bookingState: StateFlow<BookingUiState> = _bookingState

    fun createBooking(serviceId: String, serviceName: String, date: Long, notes: String) {
        val userId = authRepository.currentUserId
        if (userId == null) {
            _bookingState.value = BookingUiState.Error("User not logged in")
            return
        }

        viewModelScope.launch {
            _bookingState.value = BookingUiState.Loading
            val booking = Booking(
                userId = userId,
                serviceId = serviceId,
                serviceName = serviceName,
                requestedDate = date,
                notes = notes
            )
            when (val result = storageRepository.addBooking(booking)) {
                is Resource.Success -> _bookingState.value = BookingUiState.Success
                is Resource.Error -> _bookingState.value = BookingUiState.Error(result.message ?: "Booking failed")
                else -> {}
            }
        }
    }
    
    fun resetState() {
        _bookingState.value = BookingUiState.Idle
    }
}