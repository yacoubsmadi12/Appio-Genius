package com.example.cleantouch.data.repository

import com.example.cleantouch.data.model.Booking
import com.example.cleantouch.data.model.Service
import com.example.cleantouch.util.Resource

interface StorageRepository {
    suspend fun getServices(): Resource<List<Service>>
    suspend fun getServiceById(serviceId: String): Resource<Service?>
    suspend fun getUserBookings(userId: String): Resource<List<Booking>>
    suspend fun createBooking(booking: Booking): Resource<Unit>
}