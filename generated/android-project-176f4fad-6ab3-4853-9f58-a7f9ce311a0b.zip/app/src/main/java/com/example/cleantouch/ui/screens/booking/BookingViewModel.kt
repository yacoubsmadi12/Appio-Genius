package com.example.cleantouch.ui.screens.booking

import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.cleantouch.data.model.Booking
import com.example.cleantouch.data.model.Service
import com.example.cleantouch.data.repository.AuthRepository
import com.example.cleantouch.data.repository.StorageRepository
import com.example.cleantouch.util.Resource
import com.google.firebase.Timestamp
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.util.Date
import javax.inject.Inject

@HiltViewModel
class BookingViewModel @Inject constructor(
    private val storageRepository: StorageRepository,
    private val authRepository: AuthRepository,
    savedStateHandle: SavedStateHandle
) : ViewModel() {

    private val serviceId: String = savedStateHandle.get<String>("serviceId")!!

    private val _service = MutableStateFlow<Service?>(null)
    val service: StateFlow<Service?> = _service.asStateFlow()

    private val _bookingState = MutableStateFlow<Resource<Unit>>(Resource.Success(Unit)) // Initial state
    val bookingState: StateFlow<Resource<Unit>> = _bookingState.asStateFlow()

    init {
        fetchServiceDetails()
    }

    private fun fetchServiceDetails() {
        viewModelScope.launch {
            when (val result = storageRepository.getServiceById(serviceId)) {
                is Resource.Success -> _service.value = result.data
                is Resource.Error -> { /* Handle error */ }
                else -> {}
            }
        }
    }

    fun createBooking(address: String, date: Date) {
        viewModelScope.launch {
            _bookingState.value = Resource.Loading
            val currentUser = authRepository.currentUser
            val currentService = _service.value

            if (currentUser == null || currentService == null) {
                _bookingState.value = Resource.Error("User not logged in or service not found.")
                return@launch
            }

            val booking = Booking(
                userId = currentUser.uid,
                serviceId = currentService.id,
                serviceName = currentService.name,
                bookingDate = Timestamp(date),
                address = address,
                status = "Confirmed"
            )

            _bookingState.value = storageRepository.createBooking(booking)
        }
    }

}