package com.example.cleantouch.ui.screens.profile

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.example.cleantouch.util.Resource

@Composable
fun ProfileScreen(
    viewModel: ProfileViewModel = hiltViewModel(),
    onLogout: () -> Unit
) {
    val userState by viewModel.user.collectAsState()

    Scaffold(
        topBar = {
            TopAppBar(title = { Text("My Profile") })
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            when (val state = userState) {
                is Resource.Loading -> {
                    CircularProgressIndicator()
                }
                is Resource.Success -> {
                    state.data?.let {
                        Text(it.displayName, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(it.email, style = MaterialTheme.typography.bodyLarge)
                    }
                }
                is Resource.Error -> {
                    Text(state.message, color = MaterialTheme.colorScheme.error)
                }
            }
            Spacer(modifier = Modifier.weight(1f))
            Button(onClick = { 
                viewModel.logout()
                onLogout()
            }, modifier = Modifier.fillMaxWidth()) {
                Text("Logout")
            }
        }
    }
}