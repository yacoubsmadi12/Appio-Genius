package com.example.cleantouch.util

object Constants {
    const val USERS_COLLECTION = "users"
    const val SERVICES_COLLECTION = "services"
    const val BOOKINGS_COLLECTION = "bookings"
}