package com.example.cleantouch.data.repository

import com.example.cleantouch.data.model.Booking
import com.example.cleantouch.data.model.Service
import com.example.cleantouch.util.Constants.BOOKINGS_COLLECTION
import com.example.cleantouch.util.Constants.SERVICES_COLLECTION
import com.example.cleantouch.util.Resource
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import kotlinx.coroutines.tasks.await
import javax.inject.Inject

class StorageRepositoryImpl @Inject constructor(
    private val firestore: FirebaseFirestore
) : StorageRepository {

    override suspend fun getServices(): Resource<List<Service>> {
        return try {
            val snapshot = firestore.collection(SERVICES_COLLECTION).get().await()
            if (snapshot.isEmpty) {
                addDummyServices() // Add dummy data if collection is empty
                val newSnapshot = firestore.collection(SERVICES_COLLECTION).get().await()
                Resource.Success(newSnapshot.toObjects(Service::class.java))
            } else {
                Resource.Success(snapshot.toObjects(Service::class.java))
            }
        } catch (e: Exception) {
            Resource.Error(e.message ?: "Failed to fetch services.")
        }
    }

    override suspend fun getServiceById(serviceId: String): Resource<Service?> {
        return try {
            val document = firestore.collection(SERVICES_COLLECTION).document(serviceId).get().await()
            Resource.Success(document.toObject(Service::class.java))
        } catch (e: Exception) {
            Resource.Error(e.message ?: "Failed to fetch service details.")
        }
    }

    override suspend fun getUserBookings(userId: String): Resource<List<Booking>> {
        return try {
            val snapshot = firestore.collection(BOOKINGS_COLLECTION)
                .whereEqualTo("userId", userId)
                .orderBy("bookingDate", Query.Direction.DESCENDING)
                .get()
                .await()
            Resource.Success(snapshot.toObjects(Booking::class.java))
        } catch (e: Exception) {
            Resource.Error(e.message ?: "Failed to fetch bookings.")
        }
    }

    override suspend fun createBooking(booking: Booking): Resource<Unit> {
        return try {
            val docRef = firestore.collection(BOOKINGS_COLLECTION).document()
            val newBooking = booking.copy(id = docRef.id)
            docRef.set(newBooking).await()
            Resource.Success(Unit)
        } catch (e: Exception) {
            Resource.Error(e.message ?: "Failed to create booking.")
        }
    }
    
    private suspend fun addDummyServices() {
        val dummyServices = listOf(
            Service("1", "Carpet Cleaning", "Deep steam cleaning for all types of carpets.", 99.99, "https://images.unsplash.com/photo-1585421514738-0130a218413a?q=80&w=2070"),
            Service("2", "Car Wash", "Exterior and interior car wash and detailing.", 49.99, "https://images.unsplash.com/photo-1605152349132-68053578d0c3?q=80&w=2070"),
            Service("3", "Garden Cleaning", "Lawn mowing, hedge trimming, and garden waste removal.", 149.99, "https://images.unsplash.com/photo-1621862149475-45a828b8a655?q=80&w=2071"),
            Service("4", "Kitchen Cleaning", "Complete kitchen deep clean including appliances.", 79.99, "https://images.unsplash.com/photo-1600585152220-90363fe7e115?q=80&w=2070")
        )
        try {
            dummyServices.forEach {
                firestore.collection(SERVICES_COLLECTION).document(it.id).set(it).await()
            }
        } catch (_: Exception) { 
             // Ignore errors, might be a race condition
        }
    }
}