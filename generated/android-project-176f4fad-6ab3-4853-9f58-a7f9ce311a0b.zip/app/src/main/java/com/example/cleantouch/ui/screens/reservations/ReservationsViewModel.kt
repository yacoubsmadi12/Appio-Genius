package com.example.cleantouch.ui.screens.reservations

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.cleantouch.data.model.Booking
import com.example.cleantouch.data.repository.AuthRepository
import com.example.cleantouch.data.repository.StorageRepository
import com.example.cleantouch.util.Resource
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class ReservationsViewModel @Inject constructor(
    private val storageRepository: StorageRepository,
    private val authRepository: AuthRepository
) : ViewModel() {

    private val _reservations = MutableStateFlow<Resource<List<Booking>>>(Resource.Loading)
    val reservations: StateFlow<Resource<List<Booking>>> = _reservations

    init {
        fetchUserReservations()
    }

    private fun fetchUserReservations() {
        viewModelScope.launch {
            _reservations.value = Resource.Loading
            authRepository.currentUser?.uid?.let {
                _reservations.value = storageRepository.getUserBookings(it)
            } ?: run {
                _reservations.value = Resource.Error("User not logged in.")
            }
        }
    }
}