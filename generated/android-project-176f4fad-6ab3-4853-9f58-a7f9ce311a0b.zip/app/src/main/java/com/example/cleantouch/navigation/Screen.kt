package com.example.cleantouch.navigation

sealed class Screen(val route: String) {
    object Auth : Screen("auth_screen")
    object Main : Screen("main_screen")
    object Home : Screen("home_screen")
    object Reservations : Screen("reservations_screen")
    object Profile : Screen("profile_screen")
    object ServiceDetail : Screen("service_detail_screen")
    object Booking : Screen("booking_screen")
}