package com.example.cleantouch.ui.screens.booking

import android.app.DatePickerDialog
import android.widget.DatePicker
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.example.cleantouch.util.Resource
import java.text.SimpleDateFormat
import java.util.* 

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BookingScreen(
    viewModel: BookingViewModel = hiltViewModel(),
    onBookingSuccess: () -> Unit,
    onBack: () -> Unit
) {
    val bookingState by viewModel.bookingState.collectAsState()
    var address by remember { mutableStateOf("") }
    var selectedDate by remember { mutableStateOf<Date?>(null) }

    LaunchedEffect(bookingState) {
        if (bookingState is Resource.Success) {
            onBookingSuccess()
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Book Service") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp)
        ) {
            val service by viewModel.service.collectAsState()

            service?.let {
                Text("Booking: ${it.name}", style = MaterialTheme.typography.titleLarge)
                Spacer(modifier = Modifier.height(24.dp))
            }
            
            OutlinedTextField(
                value = address,
                onValueChange = { address = it },
                label = { Text("Address") },
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(modifier = Modifier.height(16.dp))

            DatePickerButton(selectedDate) { date ->
                selectedDate = date
            }

            Spacer(modifier = Modifier.height(32.dp))

            if (bookingState is Resource.Error) {
                Text(text = (bookingState as Resource.Error).message, color = MaterialTheme.colorScheme.error)
                Spacer(modifier = Modifier.height(8.dp))
            }

            Button(
                onClick = { 
                    if (selectedDate != null && address.isNotBlank()) {
                        viewModel.createBooking(address, selectedDate!!)
                    } 
                },
                modifier = Modifier.fillMaxWidth(),
                enabled = bookingState !is Resource.Loading
            ) {
                if (bookingState is Resource.Loading) {
                    CircularProgressIndicator(modifier = Modifier.size(24.dp), color = MaterialTheme.colorScheme.onPrimary)
                } else {
                    Text("Confirm Booking")
                }
            }
        }
    }
}

@Composable
fun DatePickerButton(selectedDate: Date?, onDateSelected: (Date) -> Unit) {
    val context = LocalContext.current
    val calendar = Calendar.getInstance()

    val datePickerDialog = DatePickerDialog(
        context,
        { _: DatePicker, year: Int, month: Int, dayOfMonth: Int ->
            calendar.set(year, month, dayOfMonth)
            onDateSelected(calendar.time)
        },
        calendar.get(Calendar.YEAR),
        calendar.get(Calendar.MONTH),
        calendar.get(Calendar.DAY_OF_MONTH)
    )

    OutlinedButton(
        onClick = { datePickerDialog.show() },
        modifier = Modifier.fillMaxWidth()
    ) {
        Text(
            text = selectedDate?.let {
                SimpleDateFormat("MMMM dd, yyyy", Locale.getDefault()).format(it)
            } ?: "Select a Date",
             modifier = Modifier.padding(vertical = 8.dp)
        )
    }
}