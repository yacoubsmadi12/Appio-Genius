package com.example.cleantouch.data.repository

import com.example.cleantouch.data.model.User
import com.example.cleantouch.util.Resource
import com.google.firebase.auth.FirebaseUser
import kotlinx.coroutines.flow.Flow

interface AuthRepository {
    val currentUser: FirebaseUser?
    fun observeAuthState(): Flow<FirebaseUser?>

    suspend fun login(email: String, password: String): Resource<FirebaseUser>
    suspend fun signup(email: String, password: String, displayName: String): Resource<FirebaseUser>
    suspend fun logout()
    suspend fun getUserDetails(uid: String): Resource<User?>
}