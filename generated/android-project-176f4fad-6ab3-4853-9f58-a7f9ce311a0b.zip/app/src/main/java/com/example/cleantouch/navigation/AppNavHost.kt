package com.example.cleantouch.navigation

import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.cleantouch.ui.screens.auth.AuthScreen
import com.example.cleantouch.ui.screens.auth.AuthViewModel
import com.example.cleantouch.ui.screens.booking.BookingScreen
import com.example.cleantouch.ui.screens.home.HomeScreen
import com.example.cleantouch.ui.screens.main.MainScreen
import com.example.cleantouch.ui.screens.servicedetail.ServiceDetailScreen

@Composable
fun AppNavHost(
    navController: NavHostController = rememberNavController(),
    authViewModel: AuthViewModel = hiltViewModel()
) {
    val authState by authViewModel.authState.collectAsState()
    val startDestination = if (authState != null) Screen.Main.route else Screen.Auth.route

    NavHost(navController = navController, startDestination = startDestination) {
        composable(Screen.Auth.route) {
            AuthScreen(onAuthSuccess = {
                navController.navigate(Screen.Main.route) {
                    popUpTo(Screen.Auth.route) { inclusive = true }
                }
            })
        }

        composable(Screen.Main.route) {
            MainScreen(navController = navController)
        }

        composable(
            route = Screen.ServiceDetail.route + "/{serviceId}",
            arguments = listOf(navArgument("serviceId") { type = NavType.StringType })
        ) {
            ServiceDetailScreen(
                onNavigateToBooking = { serviceId ->
                    navController.navigate(Screen.Booking.route + "/$serviceId")
                },
                onBack = { navController.popBackStack() }
            )
        }

        composable(
            route = Screen.Booking.route + "/{serviceId}",
            arguments = listOf(navArgument("serviceId") { type = NavType.StringType })
        ) {
            BookingScreen(
                onBookingSuccess = {
                    navController.popBackStack()
                },
                onBack = { navController.popBackStack() }
            )
        }
    }
}
