package com.example.cleantouch.ui.theme

import androidx.compose.ui.graphics.Color

val PrimaryBlue = Color(0xFF00A2FF)
val SecondaryBlue = Color(0xFF6ECBFF)
val LightGray = Color(0xFFF5F5F5)
val DarkText = Color(0xFF1D1D1D)
val LightText = Color(0xFFFFFFFF)
val ErrorRed = Color(0xFFB00020)