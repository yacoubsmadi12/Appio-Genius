package com.example.cleantouch.ui.screens.servicedetail

import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.cleantouch.data.model.Service
import com.example.cleantouch.data.repository.StorageRepository
import com.example.cleantouch.util.Resource
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class ServiceDetailViewModel @Inject constructor(
    private val storageRepository: StorageRepository,
    savedStateHandle: SavedStateHandle
) : ViewModel() {

    private val _service = MutableStateFlow<Resource<Service?>>(Resource.Loading)
    val service: StateFlow<Resource<Service?>> = _service

    init {
        savedStateHandle.get<String>("serviceId")?.let {
            fetchServiceDetails(it)
        }
    }

    private fun fetchServiceDetails(serviceId: String) {
        viewModelScope.launch {
            _service.value = Resource.Loading
            _service.value = storageRepository.getServiceById(serviceId)
        }
    }
}