package com.example.cleantouch.ui.screens.auth

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.cleantouch.data.repository.AuthRepository
import com.example.cleantouch.util.Resource
import com.google.firebase.auth.FirebaseUser
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class AuthViewModel @Inject constructor(
    private val authRepository: AuthRepository
) : ViewModel() {

    sealed class AuthState {
        object Idle : AuthState()
        object Loading : AuthState()
        data class Authenticated(val user: FirebaseUser) : AuthState()
        data class Error(val message: String) : AuthState()
    }

    private val _authStateResult = MutableStateFlow<AuthState>(AuthState.Idle)
    val authStateResult: StateFlow<AuthState> = _authStateResult

    val authState = authRepository.observeAuthState()

    fun login(email: String, password: String) {
        viewModelScope.launch {
            _authStateResult.value = AuthState.Loading
            val result = authRepository.login(email.trim(), password.trim())
            _authStateResult.value = when (result) {
                is Resource.Success -> AuthState.Authenticated(result.data)
                is Resource.Error -> AuthState.Error(result.message)
                else -> AuthState.Idle // Should not happen
            }
        }
    }

    fun signup(email: String, password: String, displayName: String) {
        viewModelScope.launch {
            _authStateResult.value = AuthState.Loading
            val result = authRepository.signup(email.trim(), password.trim(), displayName.trim())
            _authStateResult.value = when (result) {
                is Resource.Success -> AuthState.Authenticated(result.data)
                is Resource.Error -> AuthState.Error(result.message)
                else -> AuthState.Idle // Should not happen
            }
        }
    }
}