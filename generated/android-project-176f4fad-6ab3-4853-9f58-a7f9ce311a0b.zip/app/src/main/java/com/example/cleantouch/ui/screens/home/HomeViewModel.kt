package com.example.cleantouch.ui.screens.home

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.cleantouch.data.model.Service
import com.example.cleantouch.data.repository.StorageRepository
import com.example.cleantouch.util.Resource
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class HomeViewModel @Inject constructor(
    private val storageRepository: StorageRepository
) : ViewModel() {

    private val _services = MutableStateFlow<Resource<List<Service>>>(Resource.Loading)
    val services: StateFlow<Resource<List<Service>>> = _services

    init {
        fetchServices()
    }

    private fun fetchServices() {
        viewModelScope.launch {
            _services.value = Resource.Loading
            _services.value = storageRepository.getServices()
        }
    }
}